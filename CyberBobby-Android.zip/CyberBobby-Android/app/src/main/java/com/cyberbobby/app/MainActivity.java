package com.cyberbobby.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private LinearLayout content;
    private TextView status;
    private int scans = 0;
    private final Set<String> known = new HashSet<>();

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setPadding(0, 12, 0, 12);
        content.addView(t); return t;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(10,18,36));
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(32,40,32,32);
        scroll.addView(content); setContentView(scroll);
        text("🛡 CyberBobby", 30, Color.WHITE);
        text("NETWORK SECURITY AGENT  •  DEMO MODE", 13, Color.rgb(125,200,255));
        status = text("Ready for your first simulated scan.", 18, Color.WHITE);
        Button scan = new Button(this); scan.setText("Run Demo Scan"); content.addView(scan);
        scan.setOnClickListener(v -> demoScan());
        text("This version uses sample devices only. It does not scan your Wi-Fi, collect data, or connect to the internet.", 14, Color.LTGRAY);
    }
    private void demoScan() {
        scans++;
        String[] ips = {"192.168.1.1", "192.168.1.105", "192.168.1.120"};
        String[] names = {"Example router", "Example Android phone", "Example unknown device"};
        status.setText("Demo scan #" + scans + " complete • 3 sample devices");
        text("SCAN RESULTS", 20, Color.WHITE);
        for (int i = 0; i < ips.length; i++) {
            boolean isNew = known.add(ips[i]);
            text((isNew ? "NEW • " : "KNOWN • ") + names[i] + "\n" + ips[i], 16, isNew ? Color.rgb(255,204,102) : Color.rgb(150,230,180));
        }
        text("Note: New means first seen during this app session, not a security threat.", 13, Color.LTGRAY);
    }
}
