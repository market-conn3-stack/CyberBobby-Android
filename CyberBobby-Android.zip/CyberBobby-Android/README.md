# CyberBobby Android (demo)

A native Android Java starter app with a dashboard and simulated device inventory. It does **not** perform network discovery or AI analysis. No permissions or internet access required.

## Build without a computer
1. On GitHub, create a new repository (private recommended).
2. Upload the project files **preserving the directory paths**, including `.github/workflows/android.yml`. The GitHub mobile web uploader may not preserve folders when uploading a ZIP. An easier method is to use Codex with a GitHub-connected repository and ask it to commit the project structure.
3. In GitHub Actions, run **Build Android APK**, or push to the `main` branch.
4. Open the successful run, download `CyberBobby-debug-apk` artifact, unzip it, and install `app-debug.apk` on Android. You may need to allow installs from your browser/files app.

A debug APK is for personal testing, not Play Store release. The build workflow is supplied but has not been executed here. Do not install APKs from unknown parties.
